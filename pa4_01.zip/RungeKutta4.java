package ode;

/**
 * Der klassische Runge-Kutta der Ordnung 4
 *
 * @author braeckle
 *
 */
public class RungeKutta4 implements Einschrittverfahren {

    @Override
    /**
     * {@inheritDoc}
     * Bei der Umsetzung koennen die Methoden addVectors und multScalar benutzt werden.
     */
    public double[] nextStep(double[] y_k, double t, double delta_t, ODE ode) {
        double t_k1 = t + delta_t;
        double[] T1 = ode.auswerten(t, y_k);
        double[] T2 = ode.auswerten(t + (delta_t/2), addVectors(y_k, multScalar(T1, (delta_t / 2))));
        double[] T3 = ode.auswerten(t + (delta_t/2), addVectors(y_k, multScalar(T2, (delta_t / 2))));
        double[] T4 = ode.auswerten(t_k1, addVectors(y_k, multScalar(T3, (delta_t))));

        return addVectors(y_k, addVectorMul4(T1, T2, T3, T4, delta_t/6));
    }

    /**
     * addiert die zwei Vektoren a und b
     */
    private double[] addVectors(double[] a, double[] b) {
        double[] erg = new double[a.length];
        for (int i = 0; i < a.length; i++) {
            erg[i] = a[i] + b[i];
        }
        return erg;
    }

    private double[] addVectorMul4(double[] a, double[] b, double[] c, double[] d, double scalar) {
        return multScalar(addVectors(addVectors(addVectors(a, b), c), d), scalar);
    }

    /**
     * multipliziert den Skalar scalar auf den Vektor a
     */
    private double[] multScalar(double[] a, double scalar) {
        double[] erg = new double[a.length];
        for (int i = 0; i < a.length; i++) {
            erg[i] = scalar * a[i];
        }
        return erg;
    }

}

