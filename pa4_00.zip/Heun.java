package ode;

/**
 * Das Einschrittverfahren von Heun
 *
 * @author braeckle
 *
 */
public class Heun implements Einschrittverfahren {

    @Override
    /**
     * {@inheritDoc}
     * Nutzen Sie dabei geschickt den Expliziten Euler.
     */

    public double[] nextStep(double[] y_k, double t, double delta_t, ODE ode) {
        ExpliziterEuler euler = new ExpliziterEuler();
        double[] y_k_f = ode.auswerten(t, y_k);
        double[] y_k_f_delta = ode.auswerten(t + delta_t, euler.nextStep(y_k, t, delta_t, ode));
        for(int i = 0; i < y_k.length; i++) {
            y_k[i] = y_k[i] + (delta_t / 2) * (y_k_f[i] + y_k_f_delta[i]);
        }
        return y_k;
    }

}

